package com.saqibestates.app.modules.chatsone.`data`.model

class ChatsOneModel()
