package com.saqibestates.app.modules.schedulecalendartwo.`data`.model

import kotlin.String

data class SpinnerZipcodeModel(
  val itemName: String
)
