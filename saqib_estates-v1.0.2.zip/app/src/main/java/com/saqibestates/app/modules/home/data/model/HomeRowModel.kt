package com.saqibestates.app.modules.home.`data`.model

class HomeRowModel()
