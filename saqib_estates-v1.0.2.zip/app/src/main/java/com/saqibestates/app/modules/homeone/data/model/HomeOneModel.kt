package com.saqibestates.app.modules.homeone.`data`.model

import com.saqibestates.app.R
import com.saqibestates.app.appcomponents.di.MyApp
import kotlin.String

data class HomeOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtWelcome: String? = MyApp.getInstance().resources.getString(R.string.lbl_welcome)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtThomas: String? = MyApp.getInstance().resources.getString(R.string.lbl_thomas)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNewYork: String? = MyApp.getInstance().resources.getString(R.string.lbl_new_york)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtReviews: String? = MyApp.getInstance().resources.getString(R.string.lbl_reviews)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLukasJerrik: String? = MyApp.getInstance().resources.getString(R.string.lbl_lukas_jerrik)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNothingtocomp: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nothing_to_comp)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFive: String? = MyApp.getInstance().resources.getString(R.string.lbl_5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtErnaElse: String? = MyApp.getInstance().resources.getString(R.string.lbl_erna_else)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMikewasourHa: String? =
      MyApp.getInstance().resources.getString(R.string.msg_mike_was_our_ha)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFour: String? = MyApp.getInstance().resources.getString(R.string.lbl_4)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLukasJerrikOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_lukas_jerrik)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNothingtocompOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nothing_to_comp)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFiveOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLukasJerrikTwo: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_lukas_jerrik)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNothingtocompTwo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nothing_to_comp)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFiveTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtErnaElseOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_erna_else)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMikewasourHaOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_mike_was_our_ha)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFourOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_4)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLukasJerrikThree: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_lukas_jerrik)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNothingtocompThree: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nothing_to_comp)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFiveThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtThreeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_3)

)
