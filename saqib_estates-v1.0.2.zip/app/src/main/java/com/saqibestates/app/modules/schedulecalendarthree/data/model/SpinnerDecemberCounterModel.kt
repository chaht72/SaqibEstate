package com.saqibestates.app.modules.schedulecalendarthree.`data`.model

import kotlin.String

data class SpinnerDecemberCounterModel(
  val itemName: String
)
