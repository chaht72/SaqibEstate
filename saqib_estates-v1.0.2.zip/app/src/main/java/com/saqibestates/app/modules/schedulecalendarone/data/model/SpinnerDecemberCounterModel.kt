package com.saqibestates.app.modules.schedulecalendarone.`data`.model

import kotlin.String

data class SpinnerDecemberCounterModel(
  val itemName: String
)
